/**
 * @author Balaji
 *
 *         20-Feb-2017 - Balaji creation ProjectUserDto.java
 */
package com.neemShade.TmTracker.dto;

import com.neemShade.TmTracker.pojo.ProjectUser;

/**
 * @author Balaji
 *
 */
public class ProjectUserDto {
	
	private ProjectUser projectUser;

	public ProjectUser getProjectUser() {
		return projectUser;
	}

	public void setProjectUser(ProjectUser projectUser) {
		this.projectUser = projectUser;
	}

}
