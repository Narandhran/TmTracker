/**
 * @author Balaji
 *
 *         17-Feb-2017 - Balaji creation UserDto.java
 */
package com.neemShade.TmTracker.dto;

import java.util.List;

import com.neemShade.TmTracker.pojo.ProjectUser;
import com.neemShade.TmTracker.pojo.User;

/**
 * @author Balaji
 *
 */
public class UserDto {
	private User user;
	
	private ProjectUser completedProject;
	
	private List<ClubDto> clubs;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ProjectUser getCompletedProject() {
		return completedProject;
	}

	public void setCompletedProject(ProjectUser completedProject) {
		this.completedProject = completedProject;
	}

	public List<ClubDto> getClubs() {
		return clubs;
	}

	public void setClubs(List<ClubDto> clubs) {
		this.clubs = clubs;
	}
	
	
}
